<?php include("../header.php") ?>
    <div>
        <h1 style="background-color: brown; padding: .5%; color: white;">Recent projects</h1>
        <ul>
            <li><h3>Alzheimers exploratory data analysis</h3><a href="#"><button>Read project</button></a></li>
            <li><h3>ECG signal digital filter using C++</h3><a href="#"><button disabled>Read project</button></a> &nbsp; under deveplopment!</li>
            <li><h3>High noise warning device for NICU</h3><a href="#"><button disabled>Read project</button></a> &nbsp; under deveplopment!</li>
            <li><h3>Shazam clone using Python</h3><a href="#"><button disabled>Read project</button></a> &nbsp; under deveplopment!</li>
        </ul>
    </div>
<?php include("../footer.php") ?>