<footer style="text-align: center;">
    <hr />
        <p><a href="https://www.linkedin.com/in/fdiez1/" target="_blank">Linkedin</a> | <a href="mailto:me@fdiez.com.ar">Email</a> | <a href="https://github.com/fdiezdev" target="_blank">Github</a> | <a href="https://www.youtube.com/@frandiezbass" target="_blank">Youtube</a></p>
        <p>&copy; Francisco Diez - <?= date('Y'); ?></p>
   </footer>
</body>
</html>